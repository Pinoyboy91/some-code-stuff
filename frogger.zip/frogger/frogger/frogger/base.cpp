#include "stdafx.h"
#include "base.h"


void base::Display()
{
	GetChar();
	Console::SetCursorPosition(GetX(), GetY());
	Console::ForegroundColor(GetColor());
	for (int i = 0; i < thing.size(); i++)
	{
		cout << thing[i];

	}
}

void base::Update()
{
	SetX(GetX() - 1);
	if (GetX() <= 0)
	{

		int random = rand() % Console::WindowHeight();
	
		if (random % 2 != 0)
		{
			random = random + 1;
			if (random >= Console::WindowHeight() - 2)
			{
				random = Console::WindowHeight() - 2;
			}
		}
		if (random < 1)
		{
			random = random + 2;
		}

		SetX(Console::WindowWidth());
		SetY(random);
	}
}

int base::GetMultiply()
{
	return 0;
}

int base::GetScore()
{
	return 0;
}

void base::SetScore(int _score)
{
}






base::base()
{
}


base::~base()
{
}
