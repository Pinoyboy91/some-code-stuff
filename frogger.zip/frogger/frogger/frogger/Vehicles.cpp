#include "stdafx.h"
#include "Vehicles.h"


void Vehicles::Update()
{
	base::Update();

}

void Vehicles::Display()
{
	base::Display();
}

Vehicles::Vehicles()
{
}


Vehicles::~Vehicles()
{
}
