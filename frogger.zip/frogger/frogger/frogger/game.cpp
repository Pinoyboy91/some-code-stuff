#include "stdafx.h"
#include "game.h"
#include <fstream>




game::game()
{
	Console::SetWindowSize(60, 40);
	Console::SetBufferSize(60, 40);
	Console::EOLWrap(false);
	Console::CursorVisible(false);

	bool a = true;
	
	int menu;
	amount = 20;
	difficulty = 2;
	int score = 0;

	ifstream fin;
	fin.open("save.txt");
	int savenumber;
	if (fin.is_open())
	{
		while (true)
		{
			if (fin.eof())
				break;
			fin >> savenumber;
			fin.ignore(INT_MAX, '\n');
			leaderboard.push_back(savenumber);
		}
	}
	while (a == true)
	{
		char *name[32];
		int temp = 0;
		base* frog = new Player(Console::WindowWidth() / 2, Console::WindowHeight(), player, ConsoleColor(Green), 0);

		system("cls");
		Console::ForegroundColor(White);
		cout << "1. Play game \n";
		cout << "2. Difficulty\n";
		cout << "3. Instructions \n";
		cout << "4. Display Scores \n";
		cout << "5. Quit \n";
		cout << "---------------- \n";
		cin >> menu;
		switch (menu)
		{
		case 1:
			PlaySound(TEXT("Frogger Theme.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);

			alive = true;
			objects.push_back(frog);
			SpawnVehicles();
		
			while (alive == true)
			{

				Console::Lock(true);
				system("cls");

				for (int i = 0; i < objects.size(); i++)
				{
					if (GetAsyncKeyState(VK_ESCAPE))
					{
						alive = false;
						a = false;
						break;
					}
					objects[i]->Update();

					if (frog->GetMultiply() > 0)
					{
						if (frog->GetMultiply() > temp)
						{
							amount = 0;
							amount = amount + (frog->GetMultiply() * difficulty);
							SpawnVehicles();
							SpawnPickup();
							temp = frog->GetMultiply();
						}

					}

					objects[i]->Display();
					collision();
					if (eat == true)
					{
						frog->SetScore(frog->GetScore() + 20);
						eat = false;
					}
					if (alive == false)
					{
						score = frog->GetScore();
						for (int i = 0; i < objects.size(); i++)
						{
							delete objects[i];
						}
						objects.clear();
						break;
					}

				}
				Console::Lock(false);
				std::this_thread::sleep_for(chrono::milliseconds(20));


				if (alive == false)
				{
					//Game Over
					cin.clear();
					cin.ignore(INT_MAX, '\n');

					system("cls");
					PlaySound(TEXT("Splat.wav"), NULL, SND_FILENAME | SND_ASYNC);

					Console::SetCursorPosition((Console::WindowWidth() / 2) - 4, Console::WindowHeight() / 2);
					cout << "GAME OVER \n";
					Console::SetCursorPosition((Console::WindowWidth() / 2) - 15, (Console::WindowHeight() / 2) + 1);
					system("pause");
					amount = 20;

					//HighScore
					Console::ForegroundColor(Green);
					system("cls");
					Console::SetCursorPosition((Console::WindowWidth() / 2) - 8, Console::WindowHeight() / 2);
					score = score * difficulty;
					cout << "Your Score is: " << score << "\n"; //<< "Please enter your First Name: ";
				//	cin >> *name[32];
					//HighScore points = HighScore(/*name,*/score);
				//	HighScore points = HighScore(*name, score);
					//leaderboard.push_back(points);
					Console::SetCursorPosition(Console::WindowWidth()/2-6, Console::WindowHeight() / 2+1);
					cout << "Saving Score";
					cout << "\n\n\n";

					//Saving
					ofstream fout;
					fout.open("save.txt", ios_base::app);
					if (fout.is_open())
					{
						fout << score << '\n';
						fout.close();
					}
					leaderboard.push_back(score);
				}
			}


			system("pause");
			break;
		case 2:
		{
			
			system("cls");
			cout << "Choose your Difficulty \n";
			cout << "1. Easy (10) * 1 points\n";
			cout << "2. Medium (20) * 2 points\n";
			cout << "3. Hard (30) * 3 points\n";
			cout << "4. Your Funeral (60)* 4 points \n";
			cout << "5. Go Back \n";
			cout << "------------------- \n";
			cin >> difficulty;
			switch (difficulty)
			{
			case 1:
				amount = 10;
				break;
			case 2:
				amount = 20;
				break;
			case 3:
				amount = 30;
				break;
			case 4:
				amount = 60;
				break;
			default:
				break;
			}
		}
			break;
		case 3:
		{
			system("cls");

			cout << "AVOID THE VEHICLES! \n\n\n";
			Console::ForegroundColor(Red);
			cout << " <[]  ";

			Console::ForegroundColor(White);
			cout << "AND  ";
			Console::ForegroundColor(Yellow);
			cout << "<[][][] \n\n";

			Console::ForegroundColor(White);
			cout << "You only move once per Key press \n\n";
			cout << "You gain points by moving forward and lose points for moving backwards \n\n";

			cout << "Controls \n";
			cout << "W = Move Up \n";
			cout << "S = Move Down \n";
			cout << "A = Move Left \n";
			cout << "D = Move Right \n";
			cout << "Space bar = Pause (press any other key to unpause) \n";
			cout << "ESC = End Program (While playing) \n";
			cout << "---------------------------------------------------- \n";
			cout << "\n";
			system("pause");
		}
			break;
		case 4:
		{
			system("cls");

			
			if (leaderboard.size() == 0)
			{
				cout << "There are no scores at this time \n";
			}
			else
			{
				//Sorting Leaderboard


				bool sort = true;
				int swap;
				HighScore temp;
				while (sort == true)
				{
					for (int i = 0; i < leaderboard.size(); i++)
					{
						sort = false;
						HighScore temp = leaderboard[i];
						for (int j = (i + 1); j < leaderboard.size(); j++)
						{
							if (temp.Gscore() < leaderboard[j].Gscore())
							{
								leaderboard[i] = leaderboard[j];
								leaderboard[j] = temp;
								sort = true;
								break;
							}
						}
					}
				}
				Console::SetCursorPosition(((Console::WindowWidth() / 2)-5), 0);
				cout << "Top Scores \n";
				for (int i = 0; i < leaderboard.size(); i++)
				{
					cout << i + 1 << ')' << " " << leaderboard[i].Gscore() << "\n"; //<< "By " << leaderboard[i].Gname()<< "\n";
				}
			}
			system("pause");
			
		}
		break;
		case 5:
			a = false;
			break;
		default:
			cin.clear();
			cin.ignore(INT_MAX, '\n');
			break;
		}
	}
}

void game::collision()
{
	for (int i = 1; i < objects.size() - 1; i++)
	{
		if (objects[i]->GetColor() == ConsoleColor(Red))
		{
			if (objects[0]->GetY() == objects[i]->GetY() &&
				(objects[0]->GetX() == objects[i]->GetX() ||
				objects[0]->GetX() == objects[i]->GetX()+1 ||
				objects[0]->GetX() == objects[i]->GetX()+2))
			{
				Console::ForegroundColor(Red);
				alive = false;
				break;
			}
		}
		if (objects[i]->GetColor() == ConsoleColor(Yellow))
		{
			if (objects[0]->GetY() == objects[i]->GetY() &&
				(objects[0]->GetX() == objects[i]->GetX() ||
				objects[0]->GetX() == objects[i]->GetX() +1 || 
				objects[0]->GetX() == objects[i]->GetX() +2 || 
				objects[0]->GetX() == objects[i]->GetX() +3 || 
				objects[0]->GetX() == objects[i]->GetX() +4 || 
				objects[0]->GetX() == objects[i]->GetX() +5 || 
				objects[0]->GetX() == objects[i]->GetX() +6))
			{
				Console::ForegroundColor(Yellow);
				alive = false;
				break;
			}
		}
		if (objects[i]->GetColor() == ConsoleColor(Cyan))
		{
			if (objects[0]->GetY() == objects[i]->GetY() &&
				objects[0]->GetX() == objects[i]->GetX())
			{
				eat = true;
				delete objects[i];
				objects.erase(objects.begin() + i);
			}
		}
		
	}
	
}

void game::SpawnVehicles()
{
	for (int i = 0; i < amount; i++)
	{
		int choice = rand() % 2;

		int width = rand() % Console::WindowWidth();
	
		int height = rand() % Console::WindowHeight();
		if (height < 3)
		{
			height = height + 3;
		}
		if (height % 2 != 0)
		{
			height = height + 1;
			if (height > Console::WindowHeight() - 2)
			{
				height = Console::WindowHeight() - 2;
			}
		}

		if (choice == 0)
		{
			base* vehicle = new Vehicles(width, height, car, ConsoleColor(Red));
			objects.push_back(vehicle);
		}
		else
		{
			base* vehicle = new Vehicles(width, height, truck, ConsoleColor(Yellow));
			objects.push_back(vehicle);
		}
		

	}
}

void game::SpawnPickup()
{
	for (int i = 0; i < difficulty; i++)
	{
		int width = rand() % Console::WindowWidth();

		int height = rand() % Console::WindowHeight();
		if (height < 3)
		{
			height = height + 3;
		}
		if (height % 2 != 0)
		{
			height = height + 1;
			if (height > Console::WindowHeight() - 2)
			{
				height = Console::WindowHeight() - 2;
			}
		}
		base* pickup = new bugs(10, 10, bug, ConsoleColor(Cyan));
		objects.push_back(pickup);

	}
}

game::~game()
{
}


