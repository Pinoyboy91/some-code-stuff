#include "stdafx.h"
#include "Truck.h"


void Truck::Update()
{
	base::Update();
}

void Truck::Display()
{
	base::Update();
}

Truck::Truck()
{
	vector <char> truck;

	truck.push_back('<');
	truck.push_back('[');
	truck.push_back(']');
	truck.push_back('[');
	truck.push_back(']');
	truck.push_back('[');
	truck.push_back(']');
	truck.push_back('[');
	truck.push_back(']');
	truck.push_back('[');
	truck.push_back(']');

}


Truck::~Truck()
{
}
