#include "stdafx.h"
#include "Player.h"


void Player::Update()
{
	
	if (GetAsyncKeyState('W'))
	{
		if (wb == true)
		{
			if (GetY() - 2 >= 2)
			{
				SetY(GetY() - 2);
				SetScore(score + 1);
			}
			else
			{
				multiply++;
				SetY(Console::WindowHeight());
				SetScore(score + 50);
			}
			wb = false;
		}
	}
	else
	{
		wb = true;
	}

	if (GetAsyncKeyState('S'))
	{
		if (sb == true)
		{
			if (GetY() + 2 <= Console::WindowHeight())
			{
				SetY(GetY() + 2);
				SetScore(score - 5);

			}
			else
			{
				SetY(2);
				SetScore(score - 50);
			}
			sb = false;
		}
	}
	else
	{
		sb = true;
	}

	if (GetAsyncKeyState('A'))
	{
		if (ab == true)
		{
			if (GetX() - 2 >=0)
			{
				SetX(GetX() - 2);
			}
			ab = false;
		}
	}
	else
	{
		ab = true;
	}
	if (GetAsyncKeyState('D'))
	{
		if (db == true)
		{
			if (GetX() + 2 <= Console::WindowWidth())
			{
				SetX(GetX() + 2);
			}
			db = false;
		}
	}
	else
	{
		db = true;
	}

	if (GetAsyncKeyState(VK_SPACE))
	{
		system("pause");
	}
}

void Player::Display()
{
	Console::SetCursorPosition(1, 0);
	Console::ForegroundColor(Cyan);
	cout << "Score: " << GetScore();

	Console::SetCursorPosition(0, 1);
	Console::ForegroundColor(White);
	for (int j = 0; j < Console::WindowWidth(); j++)
	{
		cout << "-";
	}

	for (int i = 3; i < Console::WindowHeight(); i+=2)
	{
		Console::SetCursorPosition(0, i);
		Console::ForegroundColor(Gray);
		
		for (int j = 0; j < Console::WindowWidth(); j++)
		{
			
			cout << "-";
			//count++;
		}

	}
	
	Console::SetCursorPosition(0, Console::WindowHeight());
	Console::ForegroundColor(White);
	for (int i = 0; i < Console::WindowWidth(); i++)
	{
		cout << "-";
	}
	base::Display();
}



Player::Player()
{
}


Player::~Player()
{
}

