#pragma once
#include "vehicles.h"
class Car :
	public Vehicles
{
public:
	Car(int _x, int _y, vector<char> _thing, ConsoleColor _color) :Vehicles(_x, _y, _thing, _color)
	{

	}
	Car();
	~Car();
	void Update();
	void Display();
};

