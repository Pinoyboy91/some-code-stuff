#pragma once
#include <vector>


using namespace std;

class base
{
	int x;
	int y;
	vector<char> thing;
	ConsoleColor color;
	
public:
	base(int _x, int _y, vector<char> _thing, ConsoleColor _color)
	{
		x = _x;
		y = _y;
		thing = _thing;
		color = _color;
	}
	int GetX()
	{
		return x;
	}
	int GetY()
	{
		return y;
	}
	ConsoleColor GetColor()
	{
		return color;
	}
	vector<char> GetChar()
	{
		return thing;
	}
	void SetX(int _x)
	{
		x = _x;
	}
	void SetY(int _y)
	{
		y = _y;
	}

	virtual void Display();
	virtual void Update();
	virtual int GetMultiply();
	virtual int GetScore();
	virtual void SetScore(int _score);
	

	base();
	~base();
};

