#include "stdafx.h"
#include "HighScore.h"


HighScore::HighScore()
{
}


HighScore::~HighScore()
{
}
