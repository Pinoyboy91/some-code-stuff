#include "stdafx.h"
#include "bugs.h"


void bugs::Display()
{
	base::Display();
}

bugs::bugs()
{
}


bugs::~bugs()
{
}
