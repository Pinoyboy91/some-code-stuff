#pragma once
#include "base.h"
class bugs :
	public base
{
public:
	bugs(int _x, int _y, vector<char>_thing, ConsoleColor _color) :base(_x, _y, _thing, _color)
	{
	
	}
	void Display();
	bugs();
	~bugs();
};

