#pragma once
#include "base.h"


class Player :
	public base
{
	int score=0;
	bool wb = true;
	bool sb = true;
	bool ab = true;
	bool db = true;
	int multiply=0;


public:
	Player(int _x, int _y, vector<char> _thing, ConsoleColor _color, int _score) :base(_x, _y, _thing, _color)
	{
		score = _score;
	}
	int GetScore()
	{
		base::GetScore();
		return score;
	}
	inline int Player::GetMultiply()
	{
		base::GetMultiply();
		return multiply;
	}
	void SetScore(int _score)
	{
		base::SetScore(_score);
		score = _score;
	}
	


	void Update();
	void Display();
	Player();
	~Player();
};

