// frogger.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "game.h"

int main()
{

	game g;
    return 0;
}

