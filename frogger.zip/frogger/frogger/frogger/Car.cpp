#include "stdafx.h"
#include "Car.h"


Car::Car()
{
	
}


Car::~Car()
{
}

void Car::Update()
{
	base::Update();
}

void Car::Display()
{
	base::Display();
}
