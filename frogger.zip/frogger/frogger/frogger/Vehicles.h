#pragma once
#include "base.h"
class Vehicles :
	public base
{
public:
	Vehicles(int _x, int _y, vector<char> _thing, ConsoleColor _color) :base(_x, _y, _thing, _color)
	{

	}
	void Update();
	void Display();
	Vehicles();
	~Vehicles();
};

