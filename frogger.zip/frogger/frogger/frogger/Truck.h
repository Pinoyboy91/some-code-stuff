#pragma once
#include "Vehicles.h"
class Truck :
	public Vehicles
{
public:
	Truck(int _x, int _y, vector<char> _thing, ConsoleColor _color) :Vehicles(_x, _y, _thing, _color)
	{

	}
	void Update();
	void Display();
	Truck();
	~Truck();
};

