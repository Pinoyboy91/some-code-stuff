#pragma once
#include "base.h"
#include "Player.h"
#include "Truck.h"
#include "Car.h"
#include "HighScore.h"
#include <mmsystem.h>
#include <Windows.h>
#include "bugs.h"


class game
{
	vector <base*> objects;
	vector <char> player{ '^' };
	vector <char> truck{ '<','[',']','[',']','[',']' };
	vector <char> car{ '<','[',']' };
	vector <char> bug{ '#' };
	vector <HighScore> leaderboard;
	int amount;
	int difficulty;
	bool alive = true;
	bool eat = false;

	


public:
	void collision();
	void SpawnVehicles();
	void SpawnPickup();
	game();
	~game();
};

