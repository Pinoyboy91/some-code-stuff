#pragma once
class HighScore
{
	//char* name[32];
	int score;
public:
	HighScore(/*char* _name[32],*/ int _score)
	{
	//	name[32] = _name[32];
		score = _score;
	}
	int Gscore()
	{
		return score;
	}
	char Gname()
	{
		//return *name[32];
	}
	
	HighScore();
	~HighScore();
};

